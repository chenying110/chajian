var _listdata= [];
_listdata[0] = {
	title:'据悉，韩国出品的成人网游《女王之刃》代言人，内地超模艾尚真被选为韩国娱乐杂志《MAXIM（箴言）》的7月刊封面女郎。为了参与《女王之刃》的宣传活动于今年五月访韩的艾尚真，在参与游戏宣传活动之余还参与了《MAXIM》杂志的照片拍摄。',
	timg:'images/rdn_4fe5f4f8ee668.jpg',
	img:'images/xes_04115e473f58bf599cbc52794a4c0e3d.jpg', 
	listimg:'images/xes_a6e95a791dcb6a6306fe518dbf3b16b3.jpg',
	picwidth:'609',
	picheight:'800',
	morelink:'#'
};
_listdata[1] = {
	title:'另一方面，《女王之刃》韩服在前不久进行最终测试，计划年内展开公测。而艾尚真的相关海报除了7月刊《MAXIM》杂志之外，也将通过《女王之刃》的官网公开。',
	timg:'images/rdn_4fe5f5031b588.jpg',
	img:'images/xes_c78dc213a6c7bdaf3fd601fd4c24a131.jpg',
	listimg:'images/xes_8d6eccfc72e408ddce5a0358fff58be4.jpg',
	picwidth:'609',
	picheight:'795',
	morelink:''
};
_listdata[2] = {
	title:'《MAXIM》于美国创刊后，因给读者提供性、男女关系和日常生活方方面面的建议，以及关于电影、游戏和音乐的评论，还有衣不蔽体的女郎、演员或者模特的照片，并配有充满挑逗性的采访文章，很快人气暴涨，成为全美销量最大的男性生活娱乐杂志。目前，已有多个国家的版本，这其中就包含韩国版。',
	timg:'images/rdn_4fe5f554b85c0.jpg',
	img:'images/xes_c0a7c52195eba83b8b2ee81abd5c4ce0.jpg',
	listimg:'images/xes_d09d06abaf425a9f64a4760c91bdbf96.jpg',
	picwidth:'420',
	picheight:'630',
	morelink:''
};
_listdata[3] = {
	title:'《MAXIM》杂志女郎',
	timg:'images/rdn_4fe5f5576aef6.jpg',
	img:'images/xes_228bfeb5af191a13aedf5ad1abfb9804.jpg',
	listimg:'images/xes_73492b4e9e4f0396794ac820d5a575f6.jpg',
	picwidth:'420',
	picheight:'548',
	morelink:''
};
_listdata[4] = {
	title:'《MAXIM》杂志女郎',
	timg:'images/rdn_4fe5f55aaf41b.jpg',
	img:'images/xes_01a639c9981430cf0b79251ad6674445.jpg',
	listimg:'images/xes_cb42378f915f2f76efe3587723ec397b.jpg',
	picwidth:'420',
	picheight:'705',
	morelink:''
};
_listdata[5] = {
	title:'《MAXIM》杂志女郎',
	timg:'images/rdn_4fe5f55eac481.jpg',
	img:'images/xes_25c6822b6fd35e8ae92b7dcec2009bbc.jpg',
	listimg:'images/xes_5335c63f7763232574d448dbdfa3c9b0.jpg',
	picwidth:'420',
	picheight:'630',
	morelink:''
};
_listdata[6] = {
	title:'《MAXIM》杂志女郎',
	timg:'images/rdn_4fe5f561ccf59.jpg',
	img:'images/xes_6ba4c649e427d105bf8296db9906ced7.jpg',
	listimg:'images/xes_53515cb22a54354a942ed8b71c06c623.jpg',
	picwidth:'420',
	picheight:'617',
	morelink:''
};
_listdata[7] = {
	title:'《MAXIM》杂志女郎',
	timg:'images/rdn_4fe5f5645fccb.jpg',
	img:'images/xes_677a1fa59ca7d8ed6eb4bdb638827dbe.jpg',
	listimg:'images/xes_abef0d5b72113a5c3c3198a18818a97a.jpg',
	picwidth:'420',
	picheight:'588',
	morelink:''
};
_listdata[8] = {
	title:'《MAXIM》杂志女郎',
	timg:'images/rdn_4fe5f56759e7b.jpg',
	img:'images/xes_aaf07ee19b87832c38027fcd836a41bf.jpg',
	listimg:'images/xes_73d9a467941109b2123b70dec0d2d716.jpg',
	picwidth:'420',
	picheight:'523',
	morelink:''
};
_listdata[9] = {
	title:'《MAXIM》杂志女郎',
	timg:'images/rdn_4fe5f56ad5a52.jpg',
	img:'images/xes_2399f1439a02d3dfe021f9b560550dfa.jpg',
	listimg:'images/xes_6b554e8ba7565eecd387d59d38270f81.jpg',
	picwidth:'420',
	picheight:'630',
	morelink:''
};
_listdata[10] = {
	title:'《MAXIM》杂志女郎',
	timg:'images/rdn_4fe5f56f4ed77.jpg',
	img:'images/xes_ac0f521c1bea787b70e12ba773d32aa5.jpg',
	listimg:'images/xes_d5dde0e1f14c4ae5c5099bd3a23b2af3.jpg',
	picwidth:'420',
	picheight:'549',
	morelink:''
};
_listdata[11] = {
	title:'《MAXIM》杂志女郎',
	timg:'images/rdn_4fe5f572a14ef.jpg',
	img:'images/xes_d9aad0c8e459d85494bf2955d4598c20.jpg',
	listimg:'images/xes_b83d55de504f326ed7ac1dff505fb5b8.jpg',
	picwidth:'420',
	picheight:'646',
	morelink:''
};
_listdata[12] = {
	title:'《MAXIM》杂志女郎',
	timg:'images/rdn_4fe5f574c143c.jpg',
	img:'images/xes_65095f60fcc79603f99cbcc551c062f4.jpg',
	listimg:'images/xes_3897001dcd3938d80896dde6711ae98a.jpg', 
	picwidth:'420', 
	picheight:'630',
	morelink:''
};
_listdata[13] = {
	title:'《MAXIM》杂志女郎', 
	timg:'images/rdn_4fe5f57897b79.jpg', 
	img:'images/xes_51794a7b27867e5cd54ce46d7be56cb2.jpg', 
	listimg:'images/xes_7402d5e80eaa230f0eaa8170d1113c33.jpg', 
	picwidth:'420', 
	picheight:'630',
	morelink:''
};
_listdata[14] = {
	title:'《MAXIM》杂志女郎', 
	timg:'images/rdn_4fe5f57c200c5.jpg', 
	img:'images/xes_98845d7237d421487e211433ef6efbf2.jpg', 
	listimg:'images/xes_0113d28f8d3d55ba3defa0b56435142d.jpg', 
	picwidth:'420', 
	picheight:'630',
	morelink:''
};
new ifeng.Gallery({
	photoViewMode:"skip"//"loop":循环/ "skip":下一图集
	,activeThumbCls:"current"//预览图选中的类名
	,data:_listdata
}); 